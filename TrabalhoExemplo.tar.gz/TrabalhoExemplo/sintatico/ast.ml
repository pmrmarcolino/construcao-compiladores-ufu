(* The type of the abstract syntax tree (AST). *)
type ident = string

type programa = Programa of funcoes * declaracoes * comandos
and funcoes = funcao list
and funcao = Funcao of ident * ident list * declaracoes * comandos
and declaracoes = declaracao list
and comandos = comando list
and declaracao = DecVar of ident * tipo
                                     
and tipo = TipoInt
         | TipoString
         | TipoBool

and comando = CmdAtrib of variavel * expressao
            | CmdSe of expressao * comandos * comando_senaose list * (comando_senao option)
            | CmdEntrada of variavel * expressao list
            | CmdSaida of expressao list
            | CmdEnquanto of expressao * comandos
            | CmdRetorna of expressao
            | CmdChamaFunc of variavel * chama_funcao

and comando_senaose = CmdSenaoSe of expressao * comandos
and comando_senao = CmdSenao of comandos

and variavel = Variavel of ident

and expressao = ExpVar of variavel
              | ExpInt of int
              | ExpString of string
              | ExpBool of bool
              | ExpOp of oper * expressao * expressao
              | ExpChamaFunc of oper * expressao * chama_funcao

and chama_funcao = ChamaFuncao of ident * expressao list

and oper = Mais
         | Menos
         | Mult
         | Div
         | Menor
         | Igual
         | Difer
         | Maior
         | MenorIgual
         | MaiorIgual
         | Elog
         | Oulog
