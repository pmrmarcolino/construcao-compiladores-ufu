var n = 1
var m = 2

if (n==m) {
	console.log(n)
} else {
	console.log(0)
}