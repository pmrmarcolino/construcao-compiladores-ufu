var n = 1
if (n == 1) {
	console.log(n)
} else {
	console.log(0)
}