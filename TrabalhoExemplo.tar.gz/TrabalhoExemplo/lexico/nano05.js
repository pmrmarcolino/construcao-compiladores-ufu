n = 2;
console.log(n);