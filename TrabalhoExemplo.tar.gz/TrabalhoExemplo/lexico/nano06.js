n = 1 - 2
console.log(n)