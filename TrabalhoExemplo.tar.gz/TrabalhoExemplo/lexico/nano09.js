var n = 1 + 1 / 2
if (n == 1) {
	console.log(n)
} else {
	console.log(0)
}