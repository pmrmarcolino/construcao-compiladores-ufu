var scanf = require('scanf')
console.log("Digite o primeiro numero: ")
num1 = scanf("%d")
console.log("Digite o segundo numero: ")
num2 = scanf("%d")
if(num1 > num2) {
	console.log("O primeiro numero " + num1 + " eh maior que o segundo " + num2)
} else {
	console.log("O segundo numero " + num2 + " eh maior que o primeiro " + num1)
}