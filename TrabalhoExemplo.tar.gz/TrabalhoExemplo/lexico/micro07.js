var scanf = require('scanf')
programa = 1
while (programa == 1) {
	console.log("Digite um numero: ")
	numero = scanf("%d")
	if (numero > 0) {
		console.log("Positivo")
	} else {
		if (numero == 0) {
			console.log("O numero eh igual a 0")
		} 
		if (numero < 0) {
			console.log("Negativo")
		}
	}
	console.log("Deseja finalizar? (S/N)")
	opc = scanf("%c")
	if (opc == "S") {
		programa = 0
	}
}