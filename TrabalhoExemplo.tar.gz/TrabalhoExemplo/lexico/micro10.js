function fatorial(numero) {
	if (numero <= 0) {
		return 1
	} else {
		return numero * fatorial(numero-1)
	}
}

var scanf = require("scanf")
console.log("Digite um numero: ")
numero = scanf("%d")
fat = fatorial(numero)
console.log("O fatorial de " + numero + " eh " + fat)