var scanf = require('scanf')
console.log('Digite um número: ')
numero = scanf("%d")
if(numero >= 100) {
	if(numero <= 200) {
		console.log("O numero esta no intervalo entre 100 e 200")
	} else {
		console.log("O numero não esta no intervalo entre 100 e 200")
	}
} else {
	console.log("O numero não esta no intervalo entre 100 e 200")
}