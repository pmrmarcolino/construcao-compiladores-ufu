var n = 1
var m = 2
var x = 5

while(x>n) {
	if(n == m){
		console.log(m)
	} else {
		console.log(0)
	}
	x = x - 1
}