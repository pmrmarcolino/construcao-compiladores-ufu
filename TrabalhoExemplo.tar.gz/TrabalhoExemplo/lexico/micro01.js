var scanf = require('scanf')
console.log("Tabela de conversao: Celsius -> Fahrenheit")
console.log("Digite a temperatura em Celsius: ")
cel = scanf('%d');
far = (9*cel+160)/5
console.log("A nova temperatura eh: " + far + " F")