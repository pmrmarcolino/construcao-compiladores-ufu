
(* This file was auto-generated based on "sintatico.msg". *)

(* Please note that the function [message] can raise [Not_found]. *)

let message =
  fun s ->
    match s with
    | 19 ->
        "missing '('\n"
    | 20 ->
        "unexpected token, expected an expression \n"
    | 72 ->
        "unexpected token, expected an operator or ')'\n"
    | 73 ->
        "missing '{'\n"
    | 74 ->
        "unexpected token, expected a command\n"
    | 115 ->
        "unexpected token, expected a command or '}'\n"
    | 0 ->
        "unexpected token\n"
    | 75 ->
        "unexpected token, expected an expression \n"
    | 76 ->
        "unexpected token, expected an operator, command or '}' \n"
    | 28 ->
        "unexpected token, expected an expression or function\n"
    | 69 ->
        "unexpected token, expected an operator, command, '}', ')' or end of file\n"
    | 36 ->
        "unexpected token, expected an expression or function\n"
    | 39 ->
        "unexpected token, expected an expression or function\n"
    | 40 ->
        "unexpected token, expected an operator, command, '}', ')' or end of file\n"
    | 45 ->
        "unexpected token, expected an expression or function\n"
    | 46 ->
        "unexpected token, expected an operator, command, '}', ')' or end of file\n"
    | 51 ->
        "unexpected token, expected an expression or function\n"
    | 52 ->
        "unexpected token, expected an operator, command, '}', ')' or end of file\n"
    | 47 ->
        "unexpected token, expected an expression or function\n"
    | 48 ->
        "unexpected token, expected an operator, command, '}', ')' or end of file\n"
    | 54 ->
        "unexpected token, expected an expression or function\n"
    | 55 ->
        "unexpected token, expected an operator, command, '}', ')' or end of file\n"
    | 57 ->
        "unexpected token, expected an expression or function\n"
    | 58 ->
        "unexpected token, expected an operator, command, '}', ')' or end of file\n"
    | 60 ->
        "unexpected token, expected an expression or function\n"
    | 61 ->
        "unexpected token, expected an operator, command, '}', ')' or end of file\n"
    | 63 ->
        "unexpected token, expected an expression or function\n"
    | 64 ->
        "unexpected token, expected an operator, command, '}', ')' or end of file\n"
    | 41 ->
        "unexpected token, expected an expression or function\n"
    | 65 ->
        "unexpected token, expected an expression or function \n"
    | 66 ->
        "unexpected token, expected an operator, command, '}', ')' or end of file\n"
    | 129 ->
        "unexpected token, expected a command\n"
    | 138 ->
        "unexpected token\n"
    | 25 ->
        "unexpected token, expected an expression\n"
    | 27 ->
        "unexpected token, expected ')' or an operator\n"
    | 77 ->
        "missing '('\n"
    | 78 ->
        "unexpected token, expected an expression or ')'\n"
    | 33 ->
        "unexpected token, expected ',', ')' or an operator\n"
    | 34 ->
        "unexpected token, expected an id\n"
    | 104 ->
        "unexpected token, expected a command\n"
    | 136 ->
        "unexpected token, expected a command or declaration\n"
    | 14 ->
        "unexpected token, expected an id\n"
    | 5 ->
        "unexpected token, expected an id\n"
    | 4 ->
        "unexpected token, expected a command or ','\n"
    | 131 ->
        "unexpected token, expected a command\n"
    | 15 ->
        "unexpected token, expected a command\n"
    | 137 ->
        "unexpected token, expected a command\n"
    | 81 ->
        "missing '('\n"
    | 82 ->
        "unexpected token, expected an expression\n"
    | 83 ->
        "missing ')' or operator\n"
    | 84 ->
        "missing '{'\n"
    | 85 ->
        "unexpected token, expected a command\n"
    | 95 ->
        "unexpected token, expected a command\n"
    | 96 ->
        "missing '('\n"
    | 97 ->
        "unexpected token, expected an expression\n"
    | 98 ->
        "missing ')' or operator\n"
    | 99 ->
        "missing '}'\n"
    | 100 ->
        "unexpected token, expected a command\n"
    | 123 ->
        "unexpected token, expected a command \n"
    | 118 ->
        "missing '{'\n"
    | 119 ->
        "unexpected token, expected a command\n"
    | 86 ->
        "missing '='\n"
    | 87 ->
        "unexpected token, expected an expression or function\n"
    | 92 ->
        "unexpected token, expected a operator\n"
    | 88 ->
        "missing '('\n"
    | 89 ->
        "missing ')'\n"
    | 108 ->
        "unexpected token, expected a command\n"
    | 29 ->
        "unexpected token, expect a command, operator or '('\n"
    | 30 ->
        "missing ')'\n"
    | 111 ->
        "unexpected token, expected a command\n"
    | 1 ->
        "expected function id\n"
    | 2 ->
        "expected '('\n"
    | 3 ->
        "expected ')'\n"
    | 7 ->
        "expected ')'\n"
    | 8 ->
        "expected '{'\n"
    | 9 ->
        "unexpected token, expected a command or declaration\n"
    | 127 ->
        "missing '}'\n"
    | 18 ->
        "missing '}'\n"
    | 140 ->
        "unexpected token, expected a function, declaraction, require or command\n"
    | _ ->
        raise Not_found
